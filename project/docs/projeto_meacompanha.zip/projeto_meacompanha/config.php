<?php
    define('HOST', 'localhost');
    define('USER', 'root');
    define('PASS', '');
    define('BASE', 'meacompanha');

    $conn = new Mysqli(HOST,USER,PASS,BASE);
?>